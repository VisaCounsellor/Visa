<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'profile_tabs2117' => 'profile_tabs2117',
);